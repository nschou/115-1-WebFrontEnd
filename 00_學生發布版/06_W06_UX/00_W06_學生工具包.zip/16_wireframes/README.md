# 16_wireframes

線框是 `14_elements.md` 與 `15_UX.md` 的結構驗證，不是自由發揮的視覺稿。每個畫面要標出承接任務、狀態、元素、進入／離開點與例外去處；完成後交給 `validation/`，再寫 `17_UserStory-I_AC.md`。
